
# Get the directory name for data files
import os.path
import matplotlib.pyplot as plt
directory = os.path.dirname(os.path.abspath(__file__))  

#initialize the aggregators
states=[]
number_of_people1=[]
total=[]
mo=[]
poll=[]

filename = os.path.join(directory, 'more data bruh.csv')
datafile = open(filename,'r')
data = datafile.readlines()
    # Go through all the names that year
for line in data[2:]:
    name, affect, number, percent, death = line.split(',')
        # Aggregate based on name1
        
    states += [name]
    number_of_people1 += [int(affect)]    
        #Aggregate based on name2
    poll+=[death]
    total += [int(number)]
    mo += [percent]        
    #Close that year's file
datafile.close()
    
# Plot on one set of axes.

fig, ax = plt.subplots(2,1)

ax[0].scatter((range(1,50)), mo, color = 'r')
ax[1].scatter((range(1,50)), poll, color = 'r')
ax[0].set_xticks(range(1,50))
ax[0].set_xticklabels(states)

ax[1].set_xticks(range(1,50))
ax[1].set_xticklabels(states)

ax[0].set_ylabel('Percent of population afflicted')
ax[1].set_ylabel('metric tons of CO2')
ax[1].set_xlabel('States')
fig.show()

fig, ax = plt.subplots(2,1)

ax[0].bar((range(1,50)), mo, width=0.8,color = 'g' )
ax[1].bar((range(1,50)), poll, width=0.8, color = 'g')
ax[0].set_xticks(range(1,50))
ax[0].set_xticklabels(states)

ax[1].set_xticks(range(1,50))
ax[1].set_xticklabels(states)

ax[0].set_ylabel('Percent of population afflicted')
ax[1].set_ylabel('metric tons of CO2')
ax[1].set_xlabel('States')
fig.show()


fig, ax = plt.subplots(2,1)

ax[0].plot((range(1,50)), mo, )
ax[1].plot((range(1,50)), poll )
ax[0].set_xticks(range(1,50))
ax[0].set_xticklabels(states)

ax[1].set_xticks(range(1,50))
ax[1].set_xticklabels(states)

ax[0].set_ylabel('Percent of population afflicted')
ax[1].set_ylabel('metric tons of CO2')
ax[1].set_xlabel('States')
fig.show()
